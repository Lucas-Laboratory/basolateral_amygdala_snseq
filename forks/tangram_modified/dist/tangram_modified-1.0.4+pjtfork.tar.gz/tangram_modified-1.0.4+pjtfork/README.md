# **Version:** 1.0.4+pjtfork

# tangram_modified

This is a modified version of [Tangram](https://github.com/broadinstitute/Tangram), forked locally and adapted to expose KL regularization, main loss, and total loss curves for diagnostic purposes.

Modifications include:
- Exposure of diagnostic loss curves:
  - total_loss
  - main_loss
  - kl_reg
- Useful for training diagnostics and visual inspection of loss behavior


## Installation

To install from the local folder:

```bash
pip install .
```

To install from the tarball (if built with setuptools):

```bash
pip install dist/tangram_modified-1.0.4+pjtfork.tar.gz
```

## Example: Visualizing Diagnostic Loss Curves

mapping_matrix = tg.map_cells_to_space(
    adata_sc=adata_sc,
    adata_sp=adata_sp
)
training_history = mapping_matrix.uns.get("training_history", {})
for key in ["total_loss", "main_loss", "kl_reg"]:
    if key in training_history:
        fig, ax = plt.subplots()
        ax.plot([float(v) for v in training_history[key]])
        ax.set_xlabel("Epoch")
        ax.set_ylabel("Loss")
        ax.set_title(f"Tangram Training: {key}")
        fig.tight_layout()
        plt.savefig(os.path.join(output_dir, os.path.basename(sp_path).replace(".h5ad", f"_{key}.pdf")))
        plt.close()

Modified by Peter Teravskis, 2025-04-11. Not maintained by original authors.

Forked from: https://github.com/broadinstitute/Tangram v1.0.4

This version is not maintained by the original authors. All modifications are for internal use in the Teravskis Lab.