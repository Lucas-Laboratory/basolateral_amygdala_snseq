from setuptools import setup, find_packages

setup(
    name='tangram_modified',
    version='1.0.4+pjtfork',
    packages=find_packages(),
    description='Forked and modified version of Tangram exposes diagnostic plots',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Peter Teravskis',
    license='BSD-3-Clause',
)